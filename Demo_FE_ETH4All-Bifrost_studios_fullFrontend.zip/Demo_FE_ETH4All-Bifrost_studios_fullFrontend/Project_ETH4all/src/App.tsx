import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import HomePage from "./pages/HomePage";
import AuctionDetails from "./pages/AuctionDetails";
import Auctions from "./pages/Auctions";
import ExploreDetails from "./pages/ExploreDetails";
import Explore from "./pages/Explore";
import CreateTeam from "./pages/CreateTeam";
import OrganiseTournament from "./pages/OrganiseTournament";
import { useEffect } from "react";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/auction-details":
        title = "";
        metaDescription = "";
        break;
      case "/auctions":
        title = "";
        metaDescription = "";
        break;
      case "/explore-details":
        title = "";
        metaDescription = "";
        break;
      case "/explore":
        title = "";
        metaDescription = "";
        break;
      case "/create-team":
        title = "";
        metaDescription = "";
        break;
      case "/organise-tournament":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />

      <Route path="/auction-details" element={<AuctionDetails />} />

      <Route path="/auctions" element={<Auctions />} />

      <Route path="/explore-details" element={<ExploreDetails />} />

      <Route path="/explore" element={<Explore />} />

      <Route path="/create-team" element={<CreateTeam />} />

      <Route path="/organise-tournament" element={<OrganiseTournament />} />
    </Routes>
  );
}
export default App;
