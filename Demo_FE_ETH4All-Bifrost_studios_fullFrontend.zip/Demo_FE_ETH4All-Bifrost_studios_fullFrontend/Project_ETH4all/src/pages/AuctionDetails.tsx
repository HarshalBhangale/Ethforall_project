import { FunctionComponent } from "react";
import { Button, Input } from "@chakra-ui/react";
import { ArrowForwardIcon } from "@chakra-ui/icons";

const AuctionDetails: FunctionComponent = () => {
  return (
    <div className="relative bg-gray-300 w-full h-[3230px] overflow-hidden text-left text-xl text-white font-rubik">
      <img
        className="absolute top-[156px] left-[0px] w-[699px] h-[1125px]"
        alt=""
        src="../violate-elipse-4.svg"
      />
      <div className="absolute top-[266px] left-[458px] leading-[130%] font-medium font-nunito" />
      <div className="absolute top-[14px] left-[0px] w-[1280px] h-[100px] text-2xl text-darkgray-200 font-josefin-sans">
        <div className="absolute top-[0px] left-[0px] bg-gray-200 w-[1280px] h-[100px]" />
        <div className="absolute top-[43px] right-[271.83px] w-[343.17px] h-[18px]">
          <div className="absolute top-[0px] right-[0px] w-[343.17px] h-[18px]">
            <b className="absolute top-[0px] right-[150.94px] tracking-[-0.04em] leading-[100%] inline-block w-[104.23px]">
              Streams
            </b>
            <b className="absolute top-[0px] right-[238.94px] tracking-[-0.04em] leading-[100%] inline-block text-white w-[104.23px]">
              Explore
            </b>
            <b className="absolute top-[0px] right-[0px] tracking-[-0.04em] leading-[100%] inline-block w-[165.17px]">
              Auctions
            </b>
          </div>
        </div>
        <img
          className="absolute top-[14px] left-[217px] rounded-xxl w-20 h-[75.4px] object-cover"
          alt=""
          src="../image-20@2x.png"
        />
      </div>
      <b className="absolute top-[189px] left-[233px] text-5xl leading-[187.5%]">
        Auction Details
      </b>
      <iframe
        className="absolute top-[337px] left-[224px] w-[831px] h-[493px]"
        src="https://www.youtube.com/embed/S6UwczRlFGE?rel=0"
        frameBorder="0"
        allowFullScreen
      />
      <div className="absolute top-[878px] left-[217px] w-[833px] h-[618px] text-base text-gray-200">
        <Button
          className="absolute top-[266px] left-[463px]"
          variant="solid"
          w="370px"
          colorScheme="teal"
          rightIcon={<ArrowForwardIcon />}
        >
          BUY Video NFT
        </Button>
        <div className="absolute top-[0px] left-[0px] w-[397px] h-[618px]">
          <div className="absolute h-[82.44%] w-full top-[0%] right-[0%] bottom-[17.56%] left-[0%] rounded-3xl bg-white" />
          <div className="absolute top-[163px] left-[16px] w-[345px] h-[305px]">
            <div className="absolute top-[0px] left-[0px] flex flex-row items-start justify-start gap-[159px]">
              <div className="flex flex-row items-start justify-start gap-[8px]">
                <img
                  className="relative w-[17px] h-[17px] shrink-0"
                  alt=""
                  src="../group-5.svg"
                />
                <b className="relative">Live Auction</b>
              </div>
              <div className="relative text-sm">14 Bids made</div>
            </div>
            <div className="absolute top-[44px] left-[0px] flex flex-col items-start justify-start gap-[24px]">
              <div className="w-[343px] flex flex-row items-start justify-between">
                <div className="flex flex-row items-center justify-center gap-[11px]">
                  <img
                    className="relative w-8 h-8 shrink-0 object-cover"
                    alt=""
                    src="../ellipse-1@2x.png"
                  />
                  <div className="flex flex-col items-start justify-start">
                    <div className="relative">Anna.eth</div>
                    <div className="relative text-sm font-nunito opacity-[0.56]">
                      20s
                    </div>
                  </div>
                </div>
                <div className="relative text-sm font-nunito">$24.5k</div>
              </div>
              <div className="w-[343px] flex flex-row items-start justify-between">
                <div className="flex flex-row items-center justify-center gap-[11px]">
                  <img
                    className="relative w-8 h-8 shrink-0 object-cover"
                    alt=""
                    src="../ellipse-11@2x.png"
                  />
                  <div className="flex flex-col items-start justify-start">
                    <div className="relative">GamingWinner.eth</div>
                    <div className="relative text-sm font-nunito opacity-[0.56]">
                      1m
                    </div>
                  </div>
                </div>
                <div className="relative text-sm font-nunito">$20k</div>
              </div>
              <div className="w-[343px] flex flex-row items-start justify-between">
                <div className="flex flex-row items-center justify-center gap-[11px]">
                  <img
                    className="relative w-8 h-8 shrink-0 object-cover"
                    alt=""
                    src="../ellipse-12@2x.png"
                  />
                  <div className="flex flex-col items-start justify-start">
                    <div className="relative">Ethforallhacker.eth</div>
                    <div className="relative text-sm font-nunito opacity-[0.5]">
                      5m
                    </div>
                  </div>
                </div>
                <div className="relative text-sm font-nunito">$15k</div>
              </div>
              <div className="w-[343px] flex flex-row items-start justify-between">
                <div className="flex flex-row items-center justify-center gap-[11px]">
                  <img
                    className="relative w-8 h-8 shrink-0 object-cover"
                    alt=""
                    src="../ellipse-13@2x.png"
                  />
                  <div className="flex flex-col items-start justify-start">
                    <div className="relative">Ron.hi</div>
                    <div className="relative text-sm font-nunito opacity-[0.5]">
                      7m
                    </div>
                  </div>
                </div>
                <div className="relative text-sm font-nunito">$12.5k</div>
              </div>
              <div className="w-[343px] flex flex-row items-start justify-between">
                <div className="flex flex-row items-center justify-center gap-[11px]">
                  <img
                    className="relative w-8 h-8 shrink-0 object-cover"
                    alt=""
                    src="../ellipse-14@2x.png"
                  />
                  <div className="flex flex-col items-start justify-start">
                    <div className="relative">swimmerpro.wallet</div>
                    <div className="relative text-sm font-nunito opacity-[0.5]">
                      10m
                    </div>
                  </div>
                </div>
                <div className="relative text-sm font-nunito">$10k</div>
              </div>
            </div>
          </div>
          <div className="absolute top-[26px] left-[27px] w-[343px] h-[104px]">
            <div className="absolute top-[0px] left-[0px] rounded-lg bg-whitesmoke-200 w-[343px] h-[104px]" />
            <div className="absolute top-[15px] left-[21px] flex flex-col items-start justify-start">
              <b className="relative">Starting price</b>
              <div className="relative text-sm inline-block w-[68px] h-6 shrink-0">
                $5,000
              </div>
            </div>
            <div className="absolute top-[18px] left-[200px] flex flex-col items-start justify-start">
              <b className="relative">Current Bid Price</b>
              <div className="relative text-sm">$24,500</div>
            </div>
            <div className="absolute top-[59px] left-[21px] w-[131px] h-6 text-[8px] text-black">
              <img
                className="absolute top-[0px] left-[0px] w-6 h-6 object-cover"
                alt=""
                src="../ellipse-2@2x.png"
              />
              <img
                className="absolute top-[0px] left-[14px] w-6 h-6 object-cover"
                alt=""
                src="../ellipse-21@2x.png"
              />
              <img
                className="absolute top-[0px] left-[28px] w-6 h-6 object-cover"
                alt=""
                src="../ellipse-22@2x.png"
              />
              <img
                className="absolute top-[0px] left-[42px] w-6 h-6 object-cover"
                alt=""
                src="../ellipse-23@2x.png"
              />
              <div className="absolute top-[2px] left-[70px] w-[21px] h-[21px]">
                <img
                  className="absolute top-[0px] left-[0px] w-[21px] h-[21px]"
                  alt=""
                  src="../ellipse-24.svg"
                />
                <div className="absolute top-[6px] left-[2px]">+24</div>
              </div>
              <div className="absolute top-[5px] left-[98px] text-[10px] font-nunito text-gray-100">
                are live
              </div>
            </div>
            <div className="absolute top-[14.5px] left-[170.5px] box-border w-px h-[81px] opacity-[0.1] border-r-[1px] border-solid border-gray-200" />
          </div>
        </div>
        <div className="absolute bottom-[398px] left-[458px] w-[375px] h-[214px]">
          <div className="absolute top-[0px] left-[0px] rounded-2xl bg-white [backdrop-filter:blur(10px)] w-[375px] h-[212px]" />
          <Button
            className="absolute top-[128px] left-[16px]"
            variant="solid"
            w="343px"
            colorScheme="yellow"
            rightIcon={<ArrowForwardIcon />}
          >{`Place Bid `}</Button>
          <Input
            className="bg-[transparent] absolute top-[41px] left-[16px]"
            variant="filled"
            width="343px"
            placeholder="Enter the Bid Amount"
            w="343px"
          />
        </div>
      </div>
    </div>
  );
};

export default AuctionDetails;
