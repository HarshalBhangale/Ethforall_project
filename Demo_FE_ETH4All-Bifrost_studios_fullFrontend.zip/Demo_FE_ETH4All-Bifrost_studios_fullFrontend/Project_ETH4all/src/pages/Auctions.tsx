import { FunctionComponent } from "react";
import { Button } from "@chakra-ui/react";
import { ArrowForwardIcon } from "@chakra-ui/icons";

const Auctions: FunctionComponent = () => {
  return (
    <div className="relative bg-gray-300 w-full h-[3230px] overflow-hidden text-left text-5xl text-white font-rubik">
      <img
        className="absolute top-[156px] left-[0px] w-[699px] h-[1125px]"
        alt=""
        src="../violate-elipse-41.svg"
      />
      <div className="absolute top-[1598px] left-[283px] w-[831px] h-[577px]">
        <iframe
          className="absolute top-[84px] left-[0px] rounded-base w-[831px] h-[493px] bg-[url(../public/image19@3x.png)] bg-cover bg-no-repeat bg-[top]"
          src="https://www.youtube.com/embed/WrPYkbuCCX8?rel=0"
          frameBorder="0"
          allowFullScreen
        />
        <button
          className="cursor-pointer [border:none] p-0 bg-[transparent] absolute top-[136px] left-[65px] w-[97px] h-[43.14px]"
          autoFocus
        >
          <div className="absolute top-[0px] left-[0px] rounded-xxs bg-red w-[97px] h-[43px]" />
          <b className="absolute top-[10.46px] left-[27.02px] text-3xl inline-block font-roboto text-whitesmoke-100 text-left w-[51.15px] h-[32.68px]">
            LIVE
          </b>
        </button>
        <img
          className="absolute top-[285px] left-[371px] w-[90px] h-[90px]"
          alt=""
          src="../group-784.svg"
        />
        <Button
          className="absolute top-[0px] left-[601px]"
          variant="solid"
          w="230px"
          colorScheme="teal"
          rightIcon={<ArrowForwardIcon />}
        >
          BUY Video NFT
        </Button>
      </div>
      <div className="absolute top-[304px] left-[284px] w-[831px] h-[577px]">
        <Button
          className="absolute top-[0px] left-[601px]"
          variant="solid"
          w="230px"
          colorScheme="teal"
          rightIcon={<ArrowForwardIcon />}
        >
          BUY Video NFT
        </Button>
        <iframe
          className="absolute top-[84px] left-[0px] w-[831px] h-[493px]"
          src="https://www.youtube.com/embed/S6UwczRlFGE?rel=0"
          frameBorder="0"
          allowFullScreen
        />
      </div>
      <div className="absolute top-[938px] left-[284px] w-[831px] h-[590px]">
        <Button
          className="absolute top-[0px] left-[601px]"
          variant="solid"
          w="230px"
          colorScheme="teal"
          rightIcon={<ArrowForwardIcon />}
        >
          BUY Video NFT
        </Button>
        <div className="absolute top-[97px] left-[0px] w-[830px] h-[493px]">
          <iframe
            className="absolute top-[0px] left-[0px] rounded-base w-[830px] h-[493px] bg-[url(../public/image21@3x.png)] bg-cover bg-no-repeat bg-[top]"
            src="https://www.youtube.com/embed/zRQnHnjk0gQ?rel=0"
            frameBorder="0"
            allowFullScreen
          />
          <button
            className="cursor-pointer [border:none] p-0 bg-[transparent] absolute top-[42.92px] left-[65px] w-[101px] h-[47.47px]"
            autoFocus
          >
            <div className="absolute top-[0px] left-[0px] rounded-base bg-darkgray-100 w-[97px] h-[47.32px]" />
            <b className="absolute top-[11.51px] left-[6px] text-3xl inline-block font-roboto text-whitesmoke-100 text-left w-[95px] h-[35.96px]">
              Recorded
            </b>
          </button>
          <img
            className="absolute top-[243.2px] left-[399px] w-[33px] h-[36.31px]"
            alt=""
            src="../group-7841.svg"
          />
        </div>
        <img
          className="absolute top-[313px] left-[371px] w-[90px] h-[90px]"
          alt=""
          src="../group-7842.svg"
        />
      </div>
      <b className="absolute top-[189px] left-[237px] leading-[187.5%]">
        Auctions
      </b>
      <div className="absolute top-[6px] left-[-6px] w-[1280px] h-[100px] text-2xl text-darkgray-200 font-josefin-sans">
        <div className="absolute top-[0px] left-[0px] bg-gray-200 w-[1280px] h-[100px]" />
        <div className="absolute top-[43px] right-[271.83px] w-[343.17px] h-[18px]">
          <div className="absolute top-[0px] right-[0px] w-[343.17px] h-[18px]">
            <b className="absolute top-[0px] right-[150.94px] tracking-[-0.04em] leading-[100%] inline-block w-[104.23px]">
              Streams
            </b>
            <b className="absolute top-[0px] right-[238.94px] tracking-[-0.04em] leading-[100%] inline-block text-white w-[104.23px]">
              Explore
            </b>
            <b className="absolute top-[0px] right-[0px] tracking-[-0.04em] leading-[100%] inline-block w-[165.17px]">
              Auctions
            </b>
          </div>
        </div>
        <img
          className="absolute top-[14px] left-[217px] rounded-xxl w-20 h-[75.4px] object-cover"
          alt=""
          src="../image-20@2x.png"
        />
      </div>
    </div>
  );
};

export default Auctions;
