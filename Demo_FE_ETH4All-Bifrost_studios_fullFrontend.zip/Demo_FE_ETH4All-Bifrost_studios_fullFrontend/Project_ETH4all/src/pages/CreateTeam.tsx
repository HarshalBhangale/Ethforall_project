import { FunctionComponent } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Button as BsButton } from "react-bootstrap";
import { Input } from "@chakra-ui/react";

const CreateTeam: FunctionComponent = () => {
  return (
    <div className="relative bg-gray-300 w-full h-[1016px] overflow-hidden text-left text-4xl text-white font-josefin-sans">
      <img
        className="absolute top-[156px] left-[0px] w-[699px] h-[860px]"
        alt=""
        src="../violate-elipse-44.svg"
      />
      <div className="absolute bottom-[620px] left-[calc(50%_-_375px)] w-[666px] h-12">
        <input
          className="absolute bottom-[0px] left-[calc(50%_-_56px)] w-[389px] h-12"
          type="file"
        />
        <b className="absolute bottom-[2px] left-[calc(50%_-_333px)] tracking-[-0.04em] leading-[100%] inline-block w-[173px] h-[41px]">
          Upload Thumbnail
        </b>
      </div>
      <div className="absolute bottom-[721px] left-[calc(50%_-_375px)] w-[666px] h-[54px]">
        <Input
          className="bg-[transparent] absolute bottom-[6px] left-[calc(50%_-_56px)]"
          variant="outline"
          width="389px"
          placeholder="Type Team Name "
          w="389px"
        />
        <b className="absolute bottom-[0px] left-[calc(50%_-_333px)] tracking-[-0.04em] leading-[100%] inline-block w-[173px] h-[41px]">
          Team Name
        </b>
      </div>
      <div className="absolute bottom-[498px] left-[calc(50%_-_373px)] w-[664px] h-[59px]">
        <Input
          className="bg-[transparent] absolute bottom-[11px] left-[calc(50%_-_57px)]"
          variant="outline"
          width="389px"
          placeholder="Type Leader name"
          w="389px"
        />
        <b className="absolute bottom-[0px] left-[calc(50%_-_332px)] tracking-[-0.04em] leading-[100%] inline-block w-[173px] h-[41px]">
          Leader Name
        </b>
      </div>
      <div className="absolute bottom-[393px] left-[calc(50%_-_373px)] w-[664px] h-[65px]">
        <Input
          className="bg-[transparent] absolute bottom-[17px] left-[calc(50%_-_57px)]"
          variant="outline"
          width="389px"
          placeholder="Type Leader Email"
          w="389px"
        />
        <b className="absolute bottom-[0px] left-[calc(50%_-_332px)] tracking-[-0.04em] leading-[100%] inline-block w-[173px] h-[41px]">
          Leader Email
        </b>
      </div>
      <div className="absolute bottom-[298px] left-[calc(50%_-_373px)] w-[664px] h-[61px]">
        <Input
          className="bg-[transparent] absolute bottom-[13px] left-[calc(50%_-_57px)]"
          variant="outline"
          width="389px"
          placeholder="Type Team Wallet Address"
          w="389px"
        />
        <b className="absolute bottom-[0px] left-[calc(50%_-_332px)] tracking-[-0.04em] leading-[100%] inline-block w-[173px] h-[41px]">
          Wallet Address
        </b>
      </div>
      <div className="absolute bottom-[201px] left-[calc(50%_-_375px)] w-[666px] h-12">
        <b className="absolute bottom-[0px] left-[calc(50%_-_333px)] tracking-[-0.04em] leading-[100%] inline-block w-[173px] h-[41px]">
          Player Names
        </b>
        <Input
          className="bg-[transparent] absolute bottom-[0px] left-[calc(50%_-_56px)]"
          variant="outline"
          width="389px"
          placeholder="Type Player Name"
          w="389px"
        />
      </div>
      <BsButton
        className="w-[249px] absolute bottom-[75px] left-[calc(50%_-_147px)]"
        variant="primary"
      >
        Submit
      </BsButton>
      <img
        className="absolute top-[163.32px] left-[236.28px] w-[232.78px] h-[29.12px]"
        alt=""
        src="../create-team.svg"
      />
      <div className="absolute top-[5px] left-[0px] w-[1280px] h-[100px] text-2xl text-darkgray-200">
        <div className="absolute top-[0px] left-[0px] bg-gray-200 w-[1280px] h-[100px]" />
        <div className="absolute top-[43px] right-[251px] w-[353px] h-[18px]">
          <div className="absolute top-[0px] right-[0px] w-[353px] h-[18px]">
            <b className="absolute top-[0px] right-[0px] tracking-[-0.04em] leading-[100%]">
              Create Team
            </b>
            <b className="absolute top-[0px] right-[248.77px] tracking-[-0.04em] leading-[100%] inline-block w-[104.23px]">
              Streams
            </b>
            <b className="absolute top-[0px] right-[97.83px] tracking-[-0.04em] leading-[100%] inline-block w-[165.17px]">
              View Tournaments
            </b>
          </div>
        </div>
        <img
          className="absolute top-[14px] left-[217px] rounded-xxl w-20 h-[75.4px] object-cover"
          alt=""
          src="../image-20@2x.png"
        />
      </div>
    </div>
  );
};

export default CreateTeam;
