import { FunctionComponent } from "react";
import { Button } from "@chakra-ui/react";
import { ArrowForwardIcon } from "@chakra-ui/icons";

const Explore: FunctionComponent = () => {
  return (
    <div className="relative bg-gray-300 w-full h-[3230px] overflow-hidden text-left text-base text-whitesmoke-100 font-roboto">
      <img
        className="absolute top-[156px] left-[0px] w-[699px] h-[1125px]"
        alt=""
        src="../violate-elipse-43.svg"
      />
      <div className="absolute top-[1472px] left-[203px] w-[873px] h-[921px]">
        <div className="absolute top-[133px] left-[22px] w-[851px] h-[788px]">
          <div className="absolute top-[425px] left-[1px] w-[374px] h-[357px] text-darkslategray">
            <div className="absolute top-[0px] left-[0px] rounded-small bg-white w-[374px] h-[357px]" />
            <img
              className="absolute top-[0px] left-[0px] w-[374px] h-[239px] object-cover"
              alt=""
              src="../mask-group@2x.png"
            />
            <div className="absolute h-[23.53%] w-[81.55%] top-[70.87%] right-[14.71%] bottom-[5.6%] left-[3.74%]">
              <img
                className="absolute h-[17.86%] w-[4.91%] top-[2.38%] right-[59.02%] bottom-[79.76%] left-[36.07%] max-w-full overflow-hidden max-h-full"
                alt=""
                src="../group-739.svg"
              />
              <b className="absolute top-[0px] left-[0px] text-lg">
                PUBG BattleGrounds
              </b>
              <div className="absolute top-[27px] left-[0px]">
                Enemy’s Ahead !!
              </div>
              <button
                className="cursor-pointer [border:none] p-0 bg-[transparent] absolute top-[51px] left-[0px] w-[118px] h-[33px]"
                autoFocus
              >
                <button
                  className="cursor-pointer [border:none] p-0 bg-gray-400 absolute top-[0px] left-[0px] rounded-small w-[118px] h-[33px]"
                  autoFocus
                />
                <div className="absolute top-[8px] left-[12px] text-base font-roboto text-darkslategray text-left">
                  Games: Pubg
                </div>
              </button>
              <div className="absolute top-[51px] left-[126px] w-[97px] h-[33px]">
                <div className="absolute top-[0px] left-[0px] rounded-small bg-gray-400 w-[97px] h-[33px]" />
                <div className="absolute top-[8px] left-[14px]">
                  Multiplayer
                </div>
              </div>
              <div className="absolute top-[51px] left-[231px] w-[74px] h-[33px]">
                <div className="absolute top-[0px] left-[0px] rounded-small bg-gray-400 w-[74px] h-[33px]" />
                <div className="absolute top-[8px] left-[14px]">English</div>
              </div>
            </div>
            <button
              className="cursor-pointer [border:none] p-0 bg-dimgray absolute top-[27px] left-[20px] rounded-small w-[103px] h-[25px]"
              autoFocus
            />
            <div className="absolute top-[32px] left-[33px] text-sm text-gainsboro-100">
              LAST RECORD
            </div>
          </div>
          <div className="absolute top-[0px] left-[0px] w-[374px] h-[357px]">
            <div className="absolute top-[0px] left-[0px] rounded-small bg-white w-[374px] h-[357px]" />
            <img
              className="absolute top-[0px] left-[0px] w-[374px] h-[239px] object-cover"
              alt=""
              src="../mask-group1@2x.png"
            />
            <div className="absolute top-[22px] left-[20px] w-[55px] h-[25px]">
              <div className="absolute top-[0px] left-[0px] rounded-small bg-red w-[55px] h-[25px]" />
              <b className="absolute top-[4px] left-[13px]">LIVE</b>
            </div>
            <div className="absolute h-[23.53%] w-[81.55%] top-[70.87%] right-[14.71%] bottom-[5.6%] left-[3.74%] text-darkslategray">
              <img
                className="absolute h-[17.86%] w-[4.91%] top-[2.38%] right-[59.02%] bottom-[79.76%] left-[36.07%] max-w-full overflow-hidden max-h-full"
                alt=""
                src="../group-7391.svg"
              />
              <b className="absolute top-[0px] left-[0px] text-lg">
                Asphalt 8 : Live
              </b>
              <div className="absolute top-[27px] left-[0px]">{`Watch Asphalt  game live with me!  `}</div>
              <button
                className="cursor-pointer [border:none] p-0 bg-[transparent] absolute top-[51px] left-[0px] w-[118px] h-[33px]"
                autoFocus
              >
                <button
                  className="cursor-pointer [border:none] p-0 bg-gray-400 absolute top-[0px] left-[0px] rounded-small w-[118px] h-[33px]"
                  autoFocus
                />
                <div className="absolute top-[8px] left-[12px] text-base font-roboto text-darkslategray text-left">
                  Games: Roblox
                </div>
              </button>
              <div className="absolute top-[51px] left-[126px] w-[97px] h-[33px]">
                <div className="absolute top-[0px] left-[0px] rounded-small bg-gray-400 w-[97px] h-[33px]" />
                <div className="absolute top-[8px] left-[14px]">
                  Multiplayer
                </div>
              </div>
              <div className="absolute top-[51px] left-[231px] w-[74px] h-[33px]">
                <div className="absolute top-[0px] left-[0px] rounded-small bg-gray-400 w-[74px] h-[33px]" />
                <div className="absolute top-[8px] left-[14px]">English</div>
              </div>
            </div>
          </div>
          <div className="absolute top-[0px] left-[475px] w-[374px] h-[357px]">
            <div className="absolute top-[0px] left-[0px] rounded-small bg-white w-[374px] h-[357px]" />
            <img
              className="absolute top-[0px] left-[0px] w-[374px] h-[239px] object-cover"
              alt=""
              src="../mask-group2@2x.png"
            />
            <div className="absolute top-[22px] left-[20px] w-[55px] h-[25px]">
              <div className="absolute top-[0px] left-[0px] rounded-small bg-red w-[55px] h-[25px]" />
              <b className="absolute top-[4px] left-[13px]">LIVE</b>
            </div>
            <div className="absolute h-[23.53%] w-[81.55%] top-[70.87%] right-[14.71%] bottom-[5.6%] left-[3.74%] text-darkslategray">
              <img
                className="absolute h-[17.86%] w-[4.91%] top-[2.38%] right-[59.02%] bottom-[79.76%] left-[36.07%] max-w-full overflow-hidden max-h-full"
                alt=""
                src="../group-7391.svg"
              />
              <b className="absolute top-[0px] left-[0px] text-lg">
                Uncharted 4
              </b>
              <div className="absolute top-[27px] left-[0px]">{`Watch Ucharted 4 : A thief end game with me!  `}</div>
              <button
                className="cursor-pointer [border:none] p-0 bg-[transparent] absolute top-[51px] left-[0px] w-[118px] h-[33px]"
                autoFocus
              >
                <button className="cursor-pointer [border:none] p-0 bg-gray-400 absolute top-[0px] left-[0px] rounded-small w-[118px] h-[33px]" />
                <div className="absolute top-[8px] left-[12px] text-base font-roboto text-darkslategray text-left">
                  Games: Roblox
                </div>
              </button>
              <div className="absolute top-[51px] left-[126px] w-[97px] h-[33px]">
                <div className="absolute top-[0px] left-[0px] rounded-small bg-gray-400 w-[97px] h-[33px]" />
                <div className="absolute top-[8px] left-[14px]">
                  Multiplayer
                </div>
              </div>
              <div className="absolute top-[51px] left-[231px] w-[74px] h-[33px]">
                <div className="absolute top-[0px] left-[0px] rounded-small bg-gray-400 w-[74px] h-[33px]" />
                <div className="absolute top-[8px] left-[14px]">English</div>
              </div>
            </div>
          </div>
          <div className="absolute top-[431px] left-[477px] w-[374px] h-[357px]">
            <div className="absolute top-[0px] left-[0px] rounded-small bg-white w-[374px] h-[357px]" />
            <img
              className="absolute top-[0px] left-[0px] w-[374px] h-[239px] object-cover"
              alt=""
              src="../mask-group3@2x.png"
            />
            <div className="absolute top-[22px] left-[20px] w-[55px] h-[25px]">
              <div className="absolute top-[0px] left-[0px] rounded-small bg-red w-[55px] h-[25px]" />
              <b className="absolute top-[4px] left-[13px]">LIVE</b>
            </div>
            <div className="absolute h-[23.53%] w-[83.96%] top-[70.87%] right-[12.3%] bottom-[5.6%] left-[3.74%] text-darkslategray">
              <img
                className="absolute h-[17.86%] w-[4.77%] top-[2.38%] right-[60.2%] bottom-[79.76%] left-[35.03%] max-w-full overflow-hidden max-h-full"
                alt=""
                src="../group-739.svg"
              />
              <b className="absolute top-[0px] left-[0px] text-lg">
                World Cup T20 Cricket
              </b>
              <div className="absolute top-[27px] left-[0px]">
                Enjoy and Watch cricket live
              </div>
              <button className="cursor-pointer [border:none] p-0 bg-[transparent] absolute top-[51px] left-[0px] w-[118px] h-[33px]">
                <button className="cursor-pointer [border:none] p-0 bg-gray-400 absolute top-[0px] left-[0px] rounded-small w-[118px] h-[33px]" />
                <div className="absolute top-[8px] left-[12px] text-base font-roboto text-darkslategray text-left">
                  Match: Cricket
                </div>
              </button>
              <div className="absolute top-[51px] left-[136px] w-20 h-[33px]">
                <div className="absolute top-[0px] left-[0px] rounded-small bg-gray-400 w-20 h-[33px]" />
                <div className="absolute top-[8px] left-[11.55px] inline-block w-[51.43px]">
                  England
                </div>
              </div>
              <div className="absolute top-[51px] left-[240px] w-[74px] h-[33px]">
                <div className="absolute top-[0px] left-[0px] rounded-small bg-gray-400 w-[74px] h-[33px]" />
                <div className="absolute top-[8px] left-[14px]">English</div>
              </div>
            </div>
          </div>
        </div>
        <b className="absolute top-[0px] left-[0px] text-6xl leading-[187.5%] font-rubik text-white">{`Live streaming `}</b>
      </div>
      <div className="absolute top-[1303px] left-[calc(50%_-_368px)] w-[728px] h-[106px]">
        <Button
          className="absolute top-[0px] left-[calc(50%_-_364px)]"
          variant="solid"
          w="297px"
          colorScheme="yellow"
          size="lg"
          rightIcon={<ArrowForwardIcon />}
        >
          Create Team
        </Button>
        <Button
          className="absolute top-[0px] left-[calc(50%_+_67px)]"
          variant="solid"
          w="297px"
          colorScheme="yellow"
          size="lg"
          rightIcon={<ArrowForwardIcon />}
        >
          {" "}
          Organise Tournament
        </Button>
      </div>
      <div className="absolute top-[286px] left-[203px] w-[862px] h-[937px]">
        <img
          className="absolute top-[660px] left-[460px] rounded-small w-[400px] h-[277px] object-cover"
          alt=""
          src="../rectangle-26@2x.png"
        />
        <img
          className="absolute top-[660px] left-[0px] rounded-small w-[397px] h-[277px] object-cover"
          alt=""
          src="../image-11@2x.png"
        />
        <img
          className="absolute top-[338px] left-[462px] rounded-small w-[400px] h-[277px] object-cover"
          alt=""
          src="../rectangle-24@2x.png"
        />
        <img
          className="absolute top-[339px] left-[0px] rounded-small w-[397px] h-[277px] object-cover"
          alt=""
          src="../image-111@2x.png"
        />
        <img
          className="absolute top-[0px] left-[462px] rounded-small w-[400px] h-[277px] object-cover"
          alt=""
          src="../rectangle-25@2x.png"
        />
        <img
          className="absolute top-[0px] left-[1px] rounded-small w-[400px] h-[277px] object-cover"
          alt=""
          src="../rectangle-23@2x.png"
        />
      </div>
      <b className="absolute top-[154px] left-[204px] text-6xl leading-[187.5%] font-rubik text-white">
        Upcoming Tournaments
      </b>
      <div className="absolute top-[5px] left-[0px] w-[1280px] h-[100px] text-2xl text-darkgray-200 font-josefin-sans">
        <div className="absolute top-[0px] left-[0px] bg-gray-200 w-[1280px] h-[100px]" />
        <div className="absolute top-[43px] right-[271.83px] w-[343.17px] h-[18px]">
          <div className="absolute top-[0px] right-[0px] w-[343.17px] h-[18px]">
            <b className="absolute top-[0px] right-[150.94px] tracking-[-0.04em] leading-[100%] inline-block w-[104.23px]">
              Streams
            </b>
            <b className="absolute top-[0px] right-[238.94px] tracking-[-0.04em] leading-[100%] inline-block text-white w-[104.23px]">
              Explore
            </b>
            <b className="absolute top-[0px] right-[0px] tracking-[-0.04em] leading-[100%] inline-block w-[165.17px]">
              Auctions
            </b>
          </div>
        </div>
        <img
          className="absolute top-[14px] left-[217px] rounded-xxl w-20 h-[75.4px] object-cover"
          alt=""
          src="../image-20@2x.png"
        />
      </div>
    </div>
  );
};

export default Explore;
