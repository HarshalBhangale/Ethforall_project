import { FunctionComponent } from "react";
import { Button } from "@chakra-ui/react";
import { ArrowForwardIcon } from "@chakra-ui/icons";

const ExploreDetails: FunctionComponent = () => {
  return (
    <div className="relative bg-gray-300 w-full h-[3230px] overflow-hidden text-left text-5xl text-white font-rubik">
      <img
        className="absolute top-[156px] left-[0px] w-[699px] h-[1125px]"
        alt=""
        src="../violate-elipse-42.svg"
      />
      <div className="absolute top-[321px] left-[250px] w-[813px] h-[447px]">
        <img
          className="absolute top-[0px] left-[0px] rounded-small w-[813px] h-[447px] object-cover"
          alt=""
          src="../rectangle-27@2x.png"
        />
        <div className="absolute top-[290px] left-[21px] flex flex-col items-start justify-start">
          <Button
            variant="solid"
            colorScheme="green"
            size="lg"
            rightIcon={<ArrowForwardIcon />}
          >
            Join Tournament
          </Button>
        </div>
        <Button
          className="absolute top-[358px] left-[25px]"
          variant="solid"
          colorScheme="red"
          rightIcon={<ArrowForwardIcon />}
        >
          Live Stream
        </Button>
      </div>
      <div className="absolute top-[828px] left-[221px] w-[713px] h-[301px] text-6xl">
        <b className="absolute top-[0px] left-[0px] leading-[187.5%] inline-block whitespace-pre-wrap w-[713px] h-[301px]">
          <p className="[margin-block-start:0] [margin-block-end:0px]">
            <span>🏆 PRIZE POOL Payout 1000 USDC-Polygon</span>
          </p>
          <p className="[margin-block-start:0] [margin-block-end:0px] text-4xl">
            <span> 1st: $500</span>
          </p>
          <p className="[margin-block-start:0] [margin-block-end:0px]">
            <span> 2nd: $300</span>
          </p>
          <p className="[margin-block-start:0] [margin-block-end:0px]">
            <span> 3rd: $150</span>
          </p>
          <p className="[margin-block-start:0] [margin-block-end:0px]">
            <span> 4th: $50</span>
          </p>
          <p className="[margin-block-start:0] [margin-block-end:0px]">
            <span> 5th: PUBG Swag</span>
          </p>
          <p className="m-0">
            <span>&nbsp;</span>
          </p>
        </b>
      </div>
      <div className="absolute top-[1215px] left-[215px] w-[852.38px] h-[562px]">
        <img
          className="absolute top-[97px] left-[0px] rounded-xxs w-[852.38px] h-[465px] object-cover"
          alt=""
          src="../player-1-1@2x.png"
        />
        <b className="absolute top-[0px] left-[14px] leading-[187.5%]">
          Bracket Type : Single Elimination
        </b>
      </div>
      <div className="absolute top-[16px] left-[2px] w-[1280px] h-[100px] text-2xl text-darkgray-200 font-josefin-sans">
        <div className="absolute top-[0px] left-[0px] bg-gray-200 w-[1280px] h-[100px]" />
        <div className="absolute top-[43px] right-[271.83px] w-[343.17px] h-[18px]">
          <div className="absolute top-[0px] right-[0px] w-[343.17px] h-[18px]">
            <b className="absolute top-[0px] right-[150.94px] tracking-[-0.04em] leading-[100%] inline-block w-[104.23px]">
              Streams
            </b>
            <b className="absolute top-[0px] right-[238.94px] tracking-[-0.04em] leading-[100%] inline-block text-white w-[104.23px]">
              Explore
            </b>
            <b className="absolute top-[0px] right-[0px] tracking-[-0.04em] leading-[100%] inline-block w-[165.17px]">
              Auctions
            </b>
          </div>
        </div>
        <img
          className="absolute top-[14px] left-[217px] rounded-xxl w-20 h-[75.4px] object-cover"
          alt=""
          src="../image-20@2x.png"
        />
      </div>
      <b className="absolute top-[189px] left-[237px] leading-[187.5%]">
        Tournament Details
      </b>
      <div className="absolute top-[1854px] left-[217px] w-[866px] h-[507px]">
        <img
          className="absolute top-[87px] left-[0px] rounded-xxs w-[866px] h-[420px] object-cover"
          alt=""
          src="../screenshot-20230215-091126-1@2x.png"
        />
        <b className="absolute top-[0px] left-[13px] leading-[187.5%]">
          Participants
        </b>
      </div>
    </div>
  );
};

export default ExploreDetails;
