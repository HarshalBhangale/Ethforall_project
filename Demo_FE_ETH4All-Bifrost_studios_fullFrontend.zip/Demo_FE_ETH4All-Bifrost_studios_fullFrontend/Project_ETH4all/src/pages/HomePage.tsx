import { FunctionComponent } from "react";
import { Button } from "@chakra-ui/react";
import { ArrowForwardIcon } from "@chakra-ui/icons";

const HomePage: FunctionComponent = () => {
  return (
    <div className="relative bg-gray-300 w-full h-[3893px] overflow-hidden text-left text-7xl text-white font-josefin-sans">
      <img
        className="absolute top-[1810.59px] left-[302.26px] w-[977.74px] h-[987.47px]"
        alt=""
        src="../violate-elipse-1.svg"
      />
      <img
        className="absolute top-[2414px] left-[0px] w-[752px] h-[1125px]"
        alt=""
        src="../violate-elipse-2.svg"
      />
      <div className="absolute top-[2993px] left-[228px] w-[796px] h-[533px]">
        <div className="absolute top-[60px] left-[10px] bg-darkorchid [filter:blur(1500px)] [backdrop-filter:blur(1000px)] w-[742px] h-[435px]" />
        <img
          className="absolute top-[120px] left-[73px] w-[727px] h-[421px] object-cover"
          alt=""
          src="../section-5-video-thumbnail@2x.png"
        />
        <b className="absolute top-[0px] left-[0px] tracking-[-0.04em] leading-[100%] uppercase inline-block w-[615px]">
          <p className="[margin-block-start:0] [margin-block-end:0px]">
            Bid / Mint / Watch
          </p>
          <p className="m-0">top streams</p>
        </b>
        <img
          className="absolute top-[282px] left-[391px] w-[90px] h-[90px] object-cover"
          alt=""
          src="../group-754@2x.png"
        />
      </div>
      <div className="absolute top-[2076px] left-[242px] w-[863.11px] h-[749px]">
        <img
          className="absolute top-[42px] left-[127px] w-[543px] h-[493px] object-cover"
          alt=""
          src="../section-2-image@2x.png"
        />
        <b className="absolute top-[0.86px] left-[526px] tracking-[-0.04em] leading-[100%] uppercase inline-block w-[336.5px] [transform:_rotate(-0.15deg)] [transform-origin:0_0]">
          Play record share
        </b>
        <div className="absolute top-[369px] left-[0px] w-[339px] h-[380px]">
          <b className="absolute top-[0px] left-[0px] tracking-[-0.04em] leading-[100%] uppercase inline-block w-[339px] h-[230px]">
            Show your talent
          </b>
          <div className="absolute top-[352px] left-[15px] w-[179px] h-7 text-3xl">
            <b className="absolute top-[0px] left-[0px] tracking-[-0.04em] leading-[139.5%]">
              Start Streaming
            </b>
            <img
              className="absolute top-[6.64px] left-[150px] w-[30px] h-[14.73px]"
              alt=""
              src="../cta-arrow.svg"
            />
          </div>
        </div>
        <img
          className="absolute top-[487px] left-[629px] w-[82px] h-[83px]"
          alt=""
          src="../share-icon.svg"
        />
        <img
          className="absolute top-[383px] left-[629px] w-[82px] h-[83px]"
          alt=""
          src="../record-icon.svg"
        />
      </div>
      <div className="absolute top-[-144px] left-[0px] w-[1280px] h-[869px] text-center text-[70px]">
        <img
          className="absolute top-[144px] left-[0px] w-[1280px] h-[864px] object-cover"
          alt=""
          src="../hero-background-image@2x.png"
        />
        <div className="absolute top-[869px] left-[0px] [background:linear-gradient(180deg,_#101010,_rgba(16,_16,_16,_0.8)_27.68%,_rgba(16,_16,_16,_0.5)_54.98%,_rgba(16,_16,_16,_0.1)_80.76%,_rgba(16,_16,_16,_0))] w-[1280px] h-[508px]" />
        <b className="absolute top-[352px] left-[328px] tracking-[-0.04em] leading-[100%] uppercase inline-block w-[623px]">
          <p className="[margin-block-start:0] [margin-block-end:0px]">{`A Community `}</p>
          <p className="m-0">For Gamers by Gamers</p>
        </b>
        <div className="absolute top-[586px] left-[487px] text-3xl tracking-[-0.04em] leading-[139.5%] font-open-sans text-gainsboro-200 inline-block w-[305px]">{`We together can make a dent in the Universe`}</div>
        <Button
          className="absolute top-[190px] left-[941px]"
          variant="outline"
          w="145px"
          colorScheme="teal"
          rightIcon={<ArrowForwardIcon />}
        >
          Connect wallet
        </Button>
      </div>
      <div className="absolute top-[803px] left-[-66px] w-[1522px] h-[1028px] text-center">
        <b className="absolute top-[0px] left-[317px] tracking-[-0.04em] leading-[100%] uppercase">
          Try your hands on
        </b>
        <div className="absolute top-[158px] left-[0px] w-[1522px] h-[870px] text-left text-3xl text-gainsboro-200 font-open-sans">
          <div className="absolute top-[0px] left-[389px] w-[351px] h-[415px]">
            <img
              className="absolute top-[0px] left-[0px] rounded-small w-[351px] h-[415px] object-cover"
              alt=""
              src="../game-1-image@2x.png"
            />
            <div className="absolute top-[343px] left-[0px] rounded-t-none rounded-b-small bg-gray-500 [filter:blur(0px)] [backdrop-filter:blur(20px)] w-[351px] h-[72px]" />
            <div className="absolute top-[365px] left-[23px] tracking-[-0.04em] leading-[139.5%]">
              28 Streaming
            </div>
            <img
              className="absolute top-[374px] left-[307px] w-[11px] h-[11px]"
              alt=""
              src="../game-1-online-status.svg"
            />
          </div>
          <div className="absolute top-[455px] left-[782px] w-[351px] h-[415px]">
            <img
              className="absolute top-[0px] left-[0px] rounded-small w-[351px] h-[415px] object-cover"
              alt=""
              src="../game-6-image@2x.png"
            />
            <div className="absolute top-[343px] left-[0px] rounded-t-none rounded-b-small bg-gray-500 [filter:blur(0px)] [backdrop-filter:blur(20px)] w-[351px] h-[72px]" />
            <div className="absolute top-[365px] left-[23px] tracking-[-0.04em] leading-[139.5%]">
              82 Streaming
            </div>
            <img
              className="absolute top-[374px] left-[307px] w-[11px] h-[11px]"
              alt=""
              src="../game-1-online-status.svg"
            />
          </div>
          <div className="absolute top-[455px] left-[391px] w-[351px] h-[415px]">
            <img
              className="absolute top-[0px] left-[0px] rounded-small w-[351px] h-[415px] object-cover"
              alt=""
              src="../game-5-image@2x.png"
            />
            <div className="absolute top-[343px] left-[0px] rounded-t-none rounded-b-small bg-gray-500 [filter:blur(0px)] [backdrop-filter:blur(20px)] w-[351px] h-[72px]" />
            <div className="absolute top-[365px] left-[23px] tracking-[-0.04em] leading-[139.5%]">
              No Streams
            </div>
            <img
              className="absolute top-[374px] left-[307px] w-[11px] h-[11px]"
              alt=""
              src="../game-5-online-status.svg"
            />
          </div>
          <div className="absolute top-[455px] left-[0px] w-[351px] h-[415px]">
            <img
              className="absolute top-[0px] left-[66px] rounded-small w-[351px] h-[415px] object-cover"
              alt=""
              src="../game-4-image@2x.png"
            />
            <button
              className="cursor-pointer [border:none] p-0 bg-gray-500 absolute top-[343px] left-[0px] rounded-t-none rounded-b-small [filter:blur(0px)] [backdrop-filter:blur(20px)] w-[351px] h-[72px]"
              autoFocus
            />
            <div className="absolute top-[365px] left-[23px] tracking-[-0.04em] leading-[139.5%]">
              No Streams
            </div>
            <img
              className="absolute top-[374px] left-[307px] w-[11px] h-[11px]"
              alt=""
              src="../game-1-online-status.svg"
            />
          </div>
          <div className="absolute top-[0px] left-[780px] w-[351px] h-[416px]">
            <img
              className="absolute top-[0px] left-[0px] rounded-small w-[351px] h-[415px] object-cover"
              alt=""
              src="../game-2-image@2x.png"
            />
            <div className="absolute top-[344px] left-[0px] rounded-t-none rounded-b-small bg-gray-500 [filter:blur(0px)] [backdrop-filter:blur(20px)] w-[351px] h-[72px]" />
            <div className="absolute top-[366px] left-[23px] tracking-[-0.04em] leading-[139.5%]">
              365 Streaming
            </div>
            <img
              className="absolute top-[375px] left-[307px] w-[11px] h-[11px]"
              alt=""
              src="../game-1-online-status.svg"
            />
          </div>
          <div className="absolute top-[0px] left-[1171px] w-[351px] h-[416px]">
            <img
              className="absolute top-[0px] left-[0px] rounded-small w-[351px] h-[415px] object-cover"
              alt=""
              src="../game-3-image@2x.png"
            />
            <div className="absolute top-[344px] left-[0px] rounded-t-none rounded-b-small bg-gray-500 [filter:blur(0px)] [backdrop-filter:blur(20px)] w-[351px] h-[72px]" />
            <div className="absolute top-[366px] left-[23px] tracking-[-0.04em] leading-[139.5%]">
              12 Streaming
            </div>
            <img
              className="absolute top-[1336px] left-[1412px] w-[11px] h-[11px]"
              alt=""
            />
          </div>
        </div>
      </div>
      <div className="absolute top-[3797px] left-[0px] bg-gray-200 w-[1281px] h-24" />
      <b className="absolute top-[3831px] left-[498px] text-6xl tracking-[-0.04em] leading-[139.5%] inline-block [background:linear-gradient(180deg,_#fff_93.23%,_rgba(255,_255,_255,_0.17)_99.99%,_rgba(255,_255,_255,_0))] [-webkit-background-clip:text] [-webkit-text-fill-color:transparent] w-[566px] h-[43px]">{`Made with  ❤️  by Team Bifrost Gaming `}</b>
    </div>
  );
};

export default HomePage;
