import { FunctionComponent } from "react";
import {
  Button,
  Input,
  Stack,
  MenuButton,
  Menu,
  MenuList,
  MenuItem,
} from "@chakra-ui/react";
import { ArrowForwardIcon, ChevronDownIcon } from "@chakra-ui/icons";

const OrganiseTournament: FunctionComponent = () => {
  return (
    <div className="relative bg-gray-300 w-full h-[2182px] overflow-hidden text-left text-xl text-white font-outfit">
      <img
        className="absolute top-[156px] left-[0px] w-[699px] h-[1125px]"
        alt=""
        src="../violate-elipse-45.svg"
      />
      <div className="absolute top-[189px] left-[474px] leading-[130%] font-medium font-nunito" />
      <b className="absolute top-[158px] left-[calc(50%_-_406px)] text-[40px] capitalize flex items-center w-[417px] h-[101px]">
        Organise Tournament
      </b>
      <div className="absolute top-[317px] left-[calc(50%_-_349px)] w-[748px] h-[1217.15px] text-4xl">
        <div className="absolute top-[901.84px] left-[calc(50%_-_366px)] w-[740px] h-[69.1px]">
          <b className="absolute top-[0px] left-[calc(50%_-_370px)] capitalize flex items-center w-[73px] h-[55.15px]">
            <span className="[line-break:anywhere] w-full">
              <p className="[margin-block-start:0] [margin-block-end:0px]">{`Select `}</p>
              <p className="m-0">Token</p>
            </span>
          </b>
          <div className="absolute top-[0.16px] left-[calc(50%_-_118px)] w-[488px] h-[68.94px]">
            <img
              className="absolute top-[0px] left-[calc(50%_-_244px)] rounded-large w-[75px] h-[68.94px] object-cover"
              alt=""
              src="../image-1@2x.png"
            />
            <img
              className="absolute top-[0px] left-[calc(50%_+_63px)] rounded-large w-[75px] h-[68.94px] object-cover"
              alt=""
              src="../image-2@2x.png"
            />
            <img
              className="absolute top-[0px] left-[calc(50%_-_39px)] rounded-large w-[75px] h-[68.94px] object-cover"
              alt=""
              src="../image-3@2x.png"
            />
            <img
              className="absolute top-[0px] left-[calc(50%_+_169px)] rounded-large w-[75px] h-[68.94px] object-cover"
              alt=""
              src="../image-4@2x.png"
            />
            <img
              className="absolute top-[0px] left-[calc(50%_-_141px)] rounded-large w-[75px] h-[68.94px] object-cover"
              alt=""
              src="../image-5@2x.png"
            />
          </div>
        </div>
        <div className="absolute top-[789px] left-[calc(50%_-_364px)] w-[529px] h-[68.94px]">
          <b className="absolute top-[6.43px] left-[calc(50%_-_264.5px)] capitalize flex items-center w-24 h-[55.15px]">
            <span className="[line-break:anywhere] w-full">
              <p className="[margin-block-start:0] [margin-block-end:0px]">{`Select `}</p>
              <p className="m-0">Network</p>
            </span>
          </b>
          <div className="absolute top-[0px] left-[calc(50%_-_15.5px)] w-[280px] h-[68.94px]">
            <img
              className="absolute top-[0px] left-[calc(50%_-_140px)] rounded-large w-[75px] h-[68.94px] object-cover"
              alt=""
              src="../image-1@2x.png"
            />
            <img
              className="absolute top-[0px] left-[calc(50%_+_65px)] rounded-large w-[75px] h-[68.94px] object-cover"
              alt=""
              src="../image-3@2x.png"
            />
            <img
              className="absolute top-[0px] left-[calc(50%_-_37px)] rounded-large w-[75px] h-[68.94px] object-cover"
              alt=""
              src="../image-5@2x.png"
            />
          </div>
        </div>
        <Button
          className="absolute top-[1162px] left-[calc(50%_-_168px)]"
          variant="solid"
          w="288px"
          colorScheme="yellow"
          rightIcon={<ArrowForwardIcon />}
        >
          Create Tournament
        </Button>
        <div className="absolute top-[364px] left-[calc(50%_-_374px)] w-[659.27px] h-[59.74px]">
          <Input
            className="bg-[transparent] absolute top-[0px] left-[calc(50%_-_77.64px)]"
            variant="outline"
            width="407.2727355957031px"
            placeholder="Enter No. of Participants"
            w="407.2727355957031px"
          />
          <b className="absolute top-[0.92px] left-[calc(50%_-_329.64px)] capitalize flex items-center w-[211px] h-[58.83px]">
            <span className="[line-break:anywhere] w-full">
              <p className="[margin-block-start:0] [margin-block-end:0px]">{`Number of `}</p>
              <p className="m-0">Participants</p>
            </span>
          </b>
        </div>
        <div className="absolute top-[561px] left-[calc(50%_-_372px)] w-[658.27px] h-[58.83px]">
          <Input
            className="bg-[transparent] absolute top-[0px] left-[calc(50%_-_78.14px)]"
            variant="outline"
            width="407.2727355957031px"
            placeholder="Input"
            w="407.2727355957031px"
          />
          <b className="absolute top-[0px] left-[calc(50%_-_329.14px)] capitalize flex items-center w-[211px] h-[58.83px]">
            <span className="[line-break:anywhere] w-full">
              <p className="[margin-block-start:0] [margin-block-end:0px]">{`Organising Company `}</p>
            </span>
          </b>
        </div>
        <div className="absolute top-[667px] left-[calc(50%_-_370px)] w-[658.27px] h-[58.83px]">
          <Input
            className="bg-[transparent] absolute top-[0px] left-[calc(50%_-_78.14px)]"
            variant="outline"
            width="407.2727355957031px"
            placeholder="Enter Email"
            w="407.2727355957031px"
          />
          <b className="absolute top-[0px] left-[calc(50%_-_329.14px)] capitalize flex items-center w-[211px] h-[58.83px]">
            Organising Company Email
          </b>
        </div>
        <div className="absolute top-[455px] left-[calc(50%_-_372px)] w-[660.27px] h-[58.83px]">
          <Input
            className="bg-[transparent] absolute top-[0px] left-[calc(50%_-_77.14px)]"
            variant="outline"
            width="407.2727355957031px"
            placeholder="DD_MM_YYYY HH_MM"
            w="407.2727355957031px"
          />
          <b className="absolute top-[0px] left-[calc(50%_-_330.14px)] capitalize flex items-center w-[211px] h-[58.83px]">
            Date and time
          </b>
        </div>
        <div className="absolute top-[1035px] left-[calc(50%_-_366px)] w-[653.27px] h-[58.83px]">
          <div className="absolute top-[0px] left-[calc(50%_-_326.64px)] w-[653.27px] h-[58.83px]">
            <Input
              className="bg-[transparent] absolute top-[0px] left-[calc(50%_-_80.64px)]"
              variant="outline"
              width="407.2727355957031px"
              placeholder="Type Prize Amount .."
              w="407.2727355957031px"
            />
            <b className="absolute top-[0px] left-[calc(50%_-_326.64px)] capitalize flex items-center w-[211px] h-[58.83px]">
              Prize Amount
            </b>
          </div>
        </div>
        <div className="absolute top-[217px] left-[1px] w-[648px] h-[109px]">
          <Stack className="absolute top-[9px] left-[250px]">
            <Menu>
              <MenuButton
                w="398px"
                as={Button}
                rightIcon={<ChevronDownIcon />}
                colorScheme="yellow"
              >
                Select Tournament Type
              </MenuButton>
              <MenuList>
                <MenuItem value="Single Elimination">
                  Single Elimination
                </MenuItem>
                <MenuItem value="Double Elimination">
                  Double Elimination
                </MenuItem>
                <MenuItem value="Round Robin Elimination">
                  Round Robin Elimination
                </MenuItem>
              </MenuList>
            </Menu>
          </Stack>
          <div className="absolute top-[0px] left-[calc(50%_-_324px)] w-[185px] h-[68.02px]">
            <b className="absolute top-[0px] left-[calc(50%_-_92.5px)] capitalize flex items-center w-[185px] h-[68.02px]">
              Tournament type
            </b>
          </div>
        </div>
        <div className="absolute top-[85.25px] left-[0px] w-[649px] h-[117.75px]">
          <input className="absolute top-[17.75px] left-[260px]" type="file" />
          <div className="absolute top-[0px] left-[calc(50%_-_324.5px)] w-[151px] h-[94.67px]">
            <b className="absolute top-[0px] left-[calc(50%_-_75.5px)] capitalize flex items-center w-[151px] h-[94.67px]">
              Upload Thumbnail
            </b>
          </div>
        </div>
        <div className="absolute top-[0px] left-[calc(50%_-_374px)] w-[666.27px] h-[58.83px]">
          <Input
            className="bg-[transparent] absolute top-[3px] left-[calc(50%_-_74.14px)]"
            variant="outline"
            width="407.2727355957031px"
            placeholder="Enter Event name "
            w="407.2727355957031px"
          />
          <b className="absolute top-[0px] left-[calc(50%_-_333.14px)] capitalize flex items-center w-[222px] h-[58.83px]">
            <span className="[line-break:anywhere] w-full">
              <p className="[margin-block-start:0] [margin-block-end:0px]">{`Tournament `}</p>
              <p className="m-0">name</p>
            </span>
          </b>
        </div>
      </div>
    </div>
  );
};

export default OrganiseTournament;
