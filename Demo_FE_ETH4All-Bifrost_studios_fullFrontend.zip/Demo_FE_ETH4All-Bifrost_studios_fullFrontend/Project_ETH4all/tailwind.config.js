/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        gray: {
          "100": "#14181b",
          "200": "#001b2e",
          "300": "#101010",
          "400": "rgba(0, 0, 0, 0.1)",
          "500": "rgba(255, 255, 255, 0.1)",
        },
        gainsboro: { "100": "#d8d8d8", "200": "#dad7d7" },
        white: "#fff",
        darkorchid: "#ba62ff",
        black: "#000",
        whitesmoke: { "100": "#f8f8f8", "200": "#f3f2f2" },
        darkgray: { "100": "#acacac", "200": "#9f9f9f" },
        red: "#e91b17",
        darkslategray: "#2d2d2d",
        dimgray: "#616161",
      },
      fontFamily: {
        "josefin-sans": "'Josefin Sans'",
        "open-sans": "'Open Sans'",
        nunito: "Nunito",
        rubik: "Rubik",
        roboto: "Roboto",
        outfit: "Outfit",
      },
      borderRadius: {
        xxs: "10px",
        small: "20px",
        base: "30px",
        large: "37px",
        xxl: "250px",
      },
    },
    fontSize: {
      sm: "12px",
      base: "14px",
      lg: "16px",
      xl: "17px",
      "2xl": "18px",
      "3xl": "20px",
      "4xl": "24px",
      "5xl": "31px",
      "6xl": "32px",
      "7xl": "80px",
    },
  },
  corePlugins: { preflight: false },
};
