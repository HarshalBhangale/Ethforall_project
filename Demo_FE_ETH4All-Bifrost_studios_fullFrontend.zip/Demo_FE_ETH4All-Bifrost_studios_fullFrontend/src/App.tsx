import { useState } from "react";
// import Navbar from "./Components/Navbar";
import Navbar from "./Components/Navbar";
import "@rainbow-me/rainbowkit/styles.css";
import {
  getDefaultWallets,
  RainbowKitProvider,
  midnightTheme,
} from "@rainbow-me/rainbowkit";
import { configureChains, createClient, WagmiConfig } from "wagmi";
import { polygonMumbai } from "wagmi/chains";
import { Routes, Route } from "react-router-dom";
import { jsonRpcProvider } from "wagmi/providers/jsonRpc";
import CreateTeam from "./Components/CreateTeam";
import Tournaments from "./Components/Tournaments";
import Register from "./Components/Register";
import CreateTournament from "./Components/CreateTournament";
const { chains, provider } = configureChains(
  [polygonMumbai],
  [
    jsonRpcProvider({
      rpc: (chain) => ({
        http: import.meta.env.VITE_QUICKNODE_URL,
      }),
    }),
  ]
);
const { connectors } = getDefaultWallets({
  appName: "My RainbowKit App",
  chains,
});
const wagmiClient = createClient({
  autoConnect: true,
  connectors,
  provider,
});
console.log(import.meta.env.VITE_QUICKNODE_URL);
function App() {
  const [test, settest] = useState<Boolean | null>(null);
  return (
    <>
      <WagmiConfig client={wagmiClient}>
        <RainbowKitProvider
          chains={chains}
          theme={midnightTheme({
            accentColor: "#1d4fd8",
            borderRadius: "large",
          })}
        >
          <Navbar></Navbar>

          <Routes>
            <Route
              path="/CreateTeam"
              element={<CreateTeam></CreateTeam>}
            ></Route>
            <Route path="/Tournaments" element={<Tournaments></Tournaments>}>
              {" "}
            </Route>
            <Route
              path="/Tournaments/Register"
              element={<Register></Register>}
            ></Route>
            <Route path="/Tournaments/Create" element={<CreateTournament></CreateTournament>}></Route>
          </Routes>
        </RainbowKitProvider>
      </WagmiConfig>
    </>
  );
}

export default App;
