import React, { useEffect, useState } from 'react'
import { BigNumber, Bytes, BytesLike, ethers } from 'ethers'
import { usePrepareContractWrite,useContractWrite } from 'wagmi';
import { tournamentController_address,abi_tournamentController } from './Contracts';

type Organizer ={
    name:String,
    address:String,
}

type RewardToken={
  address:String,
  chain:String
}

type Prizes={
  participantPool:BigNumber,
  viewerPool:BigNumber,
  organizerFee:BigNumber,
  totalPool:BigNumber
}

type Tournament={
  round: BigNumber,
  sizeLimit:BigNumber | undefined,
  maxParticipants:BigNumber | undefined,
  bracketType:BytesLike | undefined,
  State:BigNumber | undefined,
  Organizer: Organizer | undefined,
  RewardToken : RewardToken | undefined,
  Prizes: Prizes | undefined
}


function CreateTournament() {
  const [org,setOrg]=useState<Organizer | undefined>();
  const [orgName,setOrgName]=useState<String>("");
  const [orgAddress,setOrgAddress]=useState<String>("");
  const [tokenAddress,setTokenAddress]=useState("");
  const [tokenChain,setTokenChain]=useState("");
  const [participantPool,setParticipantPool]=useState<BigNumber | undefined>();
  const [viewerPool,setViewerPool]=useState<BigNumber | undefined>();
  const [organizerFee,setOrganizerFee]=useState<BigNumber | undefined>();
  const [prizes,setPrizes]=useState<Prizes | undefined>();
  const [tournament,setTournament]=useState<Tournament | undefined>();
  const [sizeLimit,setSizeLimit]=useState <BigNumber | undefined> ();
  const [maxParticipants,setMaxParticipants]=useState <BigNumber | undefined>();
  const bracketType=ethers.utils.formatBytes32String("SE");

  const {config,error}=usePrepareContractWrite({
    address:tournamentController_address,
    abi:abi_tournamentController,
    functionName:'createTournament',
    args:[tournament]
  })

  const {write}=useContractWrite(config);

  useEffect(()=>{
    if(write && tournament){
      write();
    }
  },[tournament]);



  const [rewardToken,setRewardToken]=useState<RewardToken | undefined>();

  const nextHandler1=()=>{
    const org1={
      name:orgName,
      address:orgAddress
    }
    setOrg(org1);
  }

  const nextHandler2=()=>{
    const rewardToken1={
      address:tokenAddress,
      chain:tokenChain
    }
    setRewardToken(rewardToken1);
  }

  const nextHandler3=()=>{
    let totalPool1:BigNumber;
    if(participantPool && viewerPool && organizerFee){
      totalPool1=participantPool.add(viewerPool).add(organizerFee);
      const prizes1={
        participantPool:participantPool,
        viewerPool:viewerPool,
        organizerFee:organizerFee,
        totalPool:totalPool1
      }
      setPrizes(prizes1);
    }
  }

  const submitHandler= () =>{
    let tournament1:Tournament;
    tournament1={
      round:ethers.BigNumber.from("0"),
      sizeLimit:sizeLimit,
      maxParticipants:maxParticipants,
      bracketType:bracketType,
      State:BigNumber.from("0"),
      Organizer:org,
      RewardToken:rewardToken,
      Prizes:prizes
    }
    setTournament(tournament1);
  }

  if(!org){
  return (
    <form className=" justify-center flex">
      <div className="mt-32 mx-auto">
        <div className="mb-6">
          <label
            htmlFor="default-input"
            className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
          >
            Organization's Name
          </label>
          <input
            type="text"
            id="default-input"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
            onChange={(e)=>{setOrgName(e.target.value)}}
          />
        </div>
        <div className="mb-6">
          <label
            htmlFor="default-input"
            className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
          >
            Organization's Address
          </label>
          <input
            type="text"
            id="default-input"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
            onChange={(e)=>{
              setOrgAddress(e.target.value)
            }}
          />
        </div>
        <button type="button" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 ml-12" onClick={nextHandler1}>Next</button>     
         </div>
    </form>
  )
  }
  else if(!rewardToken){
    return (
      <form className=" justify-center flex">
        <div className="mt-32 mx-auto">
          <div className="mb-6">
            <label
              htmlFor="default-input"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
            >
              Token's Address
            </label>
            <input
              type="text"
              id="default-input"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
              onChange={(e)=>{setTokenAddress(e.target.value)}}
            />
          </div>
          <div className="mb-6">
            <label
              htmlFor="default-input"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
            >
              Token's Chain
            </label>
            <input
              type="text"
              id="default-input"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
              onChange={(e)=>{
                setTokenChain(e.target.value)
              }}
            />
          </div>
          <button type="button" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 ml-12" onClick={nextHandler2}>Next</button>     
           </div>
      </form>
    );
  }
  else if(!prizes){
    return (
      <form className=" justify-center flex">
        <div className="mt-32 mx-auto">
          <div className="mb-6">
            <label
              htmlFor="default-input"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
            >
              Participants's Pool
            </label>
            <input
              type="text"
              id="default-input"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
              onChange={(e)=>{setParticipantPool(ethers.utils.parseEther(e.target.value))}}
            />
          </div>
          <div className="mb-6">
            <label
              htmlFor="default-input"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
            >
              Viewer's Pool
            </label>
            <input
              type="text"
              id="default-input"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
              onChange={(e)=>{setViewerPool(ethers.utils.parseEther(e.target.value))}}
            />
          </div>
          <div className="mb-6">
            <label
              htmlFor="default-input"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
            >
              Organizer's Pool
            </label>
            <input
              type="text"
              id="default-input"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
              onChange={(e)=>{setOrganizerFee(ethers.utils.parseEther(e.target.value))}}
            />
          </div>
          <button type="button" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 ml-12" onClick={
            nextHandler3
          }>Next</button>     
           </div>
      </form>
    );
  }
  else{
    return(
    <form className=" justify-center flex">
        <div className="mt-32 mx-auto">
          <div className="mb-6">
            <label
              htmlFor="default-input"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
            >
              Team Size Limit
            </label>
            <input
              type="text"
              id="default-input"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
              onChange={(e)=>{
                setSizeLimit(BigNumber.from(e.target.value))
              }}
            />
          </div>
          <div className="mb-6">
            <label
              htmlFor="default-input"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
            >
              Maximum Participants Allowed
            </label>
            <input
              type="text"
              id="default-input"
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
              onChange={(e)=>{
                setMaxParticipants(BigNumber.from(e.target.value))
              }}
            />
          </div>
          <button type="button" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 ml-12" onClick={submitHandler}>Submit</button>     
           </div>
      </form>
    )
  }
}

export default CreateTournament