import React, { useEffect, useState } from 'react'
import { BigNumber, ethers } from 'ethers'
import { usePrepareContractWrite,useContractWrite } from 'wagmi';
import { tournamentController_address,abi_tournamentController } from './Contracts';


function Register() {
    const [tournamentId,setTournamentId]=useState<BigNumber | undefined>();
    const [teamId,setTeamId]=useState<BigNumber | undefined> ();
    const {config, error}=usePrepareContractWrite({
        address:tournamentController_address,
        abi:abi_tournamentController,
        functionName:'register',
        args:[tournamentId,teamId]
    })


    const {write}= useContractWrite(config);
    useEffect(()=>{
        if(write && tournamentId && teamId){
            write();
        }
    },[teamId,tournamentId])

  return (
        <form className=" justify-center flex">
      <div className="mt-32 mx-auto">
        <div className="mb-6">
          <label
            htmlFor="default-input"
            className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
          >
            Tournament Id
          </label>
          <input
            type="text"
            id="default-input"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
            onChange={(e)=>{setTournamentId(ethers.BigNumber.from(e.target.value))}}
          />
        </div>
        <div className="mb-6">
          <label
            htmlFor="default-input"
            className="block mb-2 text-sm font-medium text-gray-900 dark:text-blue-800"
          >
            Team Id
          </label>
          <input
            type="text"
            id="default-input"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 w-52"
            onChange={(e)=>{setTeamId(ethers.BigNumber.from(e.target.value))}}
          />
        </div>
        <button type="button" className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 ml-12" >Submit</button>     
         </div>
    </form>
  )
}

export default Register