import React from 'react'

function Tournaments() {
  return (
    <div></div>
  )
}

export default Tournaments